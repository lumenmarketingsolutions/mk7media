# Fixaligner clear aligner landing page

Prepared by MK7 Media for the Fixaligner developer.

This folder is a complete static page with no build step and no framework:

```
index.html      the page
styles.css      all styles (mobile first)
app.js          booking form, tracking and attribution
images/         optimized images
```

## 1. Upload

Upload the whole folder to the server, for example to `fixaligner.com/aligners/`.
All paths are relative, so it works in any folder. Use HTTPS.

## 2. Connect the booking form (required)

Open `app.js` and set the webhook address at the top:

```js
WEBHOOK_URL: "https://n8n.fixaligner.com/webhook/aligner-landing",
```

While `WEBHOOK_URL` is empty, the form runs in demo mode: it shows the thank you
message but sends nothing.

The form sends a `POST` request with a JSON body:

| Field | Example | Notes |
|---|---|---|
| `source` | `aligner_landing` | Always the same, to tag these leads in the CRM |
| `name` | `Maya Khoury` | |
| `phone` | `+96170123456` | Digits and + only |
| `concern` | `Crowded teeth` | Answer to question 1 |
| `age` | `18 to 30` | Answer to question 2 |
| `timing` | `As soon as possible` | Answer to question 3 |
| `budget` | `Yes, that works for me` | Answer to question 4 |
| `qualified` | `true` | False when under 14 or "I need to think about it" |
| `event_id` | `lead_1764...` | Same ID as the browser Pixel Lead event (for Conversions API deduplication) |
| `page` | `https://fixaligner.com/aligners/` | |
| `submitted_at` | ISO date | |
| `utm_source` ... `utm_term`, `fbclid` | from the ad link | Keep these with the lead, they tell us which ad brought the patient |

The webhook must respond with a 2xx status. Any other status shows an error
and asks the visitor to try again or use WhatsApp.

If n8n is on a different domain from the page, allow CORS for the page's
domain on that webhook (`Access-Control-Allow-Origin`, and `Content-Type` in
allowed headers).

**Suggested n8n flow:** Webhook, then save to the CRM, then send a WhatsApp message
through YCloud to the team (and optionally a welcome message to the patient).

## 3. Tracking (already set up)

The page uses the same IDs as fixaligner.com:

- Meta Pixel `1976080666274786`
- Google Analytics 4 `G-TRB066KJCS`

Events fired:

| Action | Meta | GA4 |
|---|---|---|
| Page load | `PageView` | `page_view` |
| Form submitted | `Lead` (with `eventID`) | `generate_lead` |
| WhatsApp tap | `Contact` | `whatsapp_click` |
| Phone tap | `Contact` | `phone_click` |
| First quiz answer | | `quiz_start` |
| Any booking button | | `cta_click` |

If the server already loads the Pixel or GA through a shared template, remove
the two tracking blocks in the `<head>` of `index.html` so they don't fire twice.

## 4. Content to update

- Before and after photos: replace the placeholder boxes in the Results section.
- Dr. Elias portrait or video: replace the placeholder in the Doctor section.
- Phone and WhatsApp number: `+961 70 000 557` (search `96170000557`).
- Opening hours: in the footer.

## 5. Check before going live

1. Open the page on a phone and complete the form once.
2. Confirm the lead arrives in n8n and the CRM with the UTM fields.
3. In Meta Events Manager, Test Events, confirm `Lead` and `Contact` appear.
4. In GA4 Realtime, confirm `generate_lead` appears.
